
(function() {
  'use strict';

  window.__USAGI_STORAGE_LOADED = true;

  var K = {
    SAVED_BINS:         'usagi_saved_bins',
    SAVED_ID:           'usagi_saved_id',
    CUSTOM_NAME:        'usagi_custom_name',
    CUSTOM_EMAIL:       'usagi_custom_email',
    BG_COLOR:           'usagi_bg_color',
    HAS_CUSTOM_COLOR:   'usagi_has_custom_color',
    BG_ENABLED:         'usagi_bg_enabled',
    PAGE_BG_COLOR:      'usagi_page_bg_color',
    PAGE_HAS_CUSTOM:    'usagi_page_has_custom_color',
    TOGGLE_HIT_SOUND:   'usagi_toggle_hit_sound',
    TOGGLE_AUTO_SS:     'usagi_toggle_auto_ss',
    LOGS:               'usagi_logs',
    LOGS_CLEARED_AT:    'usagi_logs_cleared_at',
    MUSIC_NAME:         'usagi_music_name',
    MUSIC_DATA:         'usagi_music_data',
    CARD_HISTORY:       'usagi_card_history',
  };

  window.UsagiKeys = K;
  window.UsagiStorage = window.UsagiStorage || {};
  var UsagiStorage = window.UsagiStorage;

  var requestCounter = 0;
  var pendingRequests = new Map();

  function storageRequest(action, data) {
    data = data || {};
    return new Promise(function(resolve) {
      var requestId = 'storage_' + (++requestCounter) + '_' + Date.now();

      var handler = function(event) {
        if (event.data && event.data.type === 'USAGI_STORAGE_RESPONSE' && event.data.requestId === requestId) {
          window.removeEventListener('message', handler);
          pendingRequests.delete(requestId);
          resolve(event.data.result);
        }
      };

      pendingRequests.set(requestId, handler);
      window.addEventListener('message', handler);

      window.postMessage({
        type: 'USAGI_STORAGE_REQUEST',
        requestId: requestId,
        action: action,
        data: data
      }, '*');

      setTimeout(function() {
        if (pendingRequests.has(requestId)) {
          window.removeEventListener('message', handler);
          pendingRequests.delete(requestId);
          resolve(null);
        }
      }, 3000);
    });
  }

  var RANDOM_BG_COLORS = [
    "#1a1a2e", "#16213e", "#0f3460", "#1b262c", "#2c3e50",
    "#1f1f38", "#2d2d44", "#1e3a5f", "#2b2b52", "#1c1c3c"
  ];

  UsagiStorage.getRandomBgColor = function() {
    return RANDOM_BG_COLORS[Math.floor(Math.random() * RANDOM_BG_COLORS.length)];
  };

  UsagiStorage.loadBackgroundColor = function(callback) {
    storageRequest('GET', { keys: [K.BG_COLOR, K.HAS_CUSTOM_COLOR] }).then(function(result) {
      result = result || {};
      var color = result[K.BG_COLOR] || UsagiStorage.getRandomBgColor();
      var userSet = result[K.HAS_CUSTOM_COLOR] || false;
      callback(color, userSet);
    });
  };

  UsagiStorage.saveBackgroundColor = function(color, userSet) {
    var data = {};
    data[K.BG_COLOR] = color;
    data[K.HAS_CUSTOM_COLOR] = userSet !== false;
    storageRequest('SET', data);
  };

  UsagiStorage.loadCustomNameEmail = function(callback) {
    storageRequest('GET', { keys: [K.CUSTOM_NAME, K.CUSTOM_EMAIL] }).then(function(result) {
      result = result || {};
      callback(result[K.CUSTOM_NAME] || '', result[K.CUSTOM_EMAIL] || '');
    });
  };

  UsagiStorage.saveCustomName = function(name) {
    var data = {};
    data[K.CUSTOM_NAME] = name;
    storageRequest('SET', data);
  };

  UsagiStorage.saveCustomEmail = function(email) {
    var data = {};
    data[K.CUSTOM_EMAIL] = email;
    storageRequest('SET', data);
  };

  UsagiStorage.loadCardHistory = function(callback) {
    storageRequest('GET', { keys: [K.CARD_HISTORY] }).then(function(result) {
      result = result || {};
      var history = result[K.CARD_HISTORY] || [];
      callback(Array.isArray(history) ? history : []);
    });
  };

  UsagiStorage.saveCardHistory = function(history) {
    var data = {};
    data[K.CARD_HISTORY] = history.slice(-100);
    storageRequest('SET', data);
  };

  UsagiStorage.addToCardHistory = function(entry, callback) {
    UsagiStorage.loadCardHistory(function(history) {
      history.push(entry);
      UsagiStorage.saveCardHistory(history);
      if (callback) callback(history);
    });
  };

  UsagiStorage.loadSavedBINs = function(callback) {
    storageRequest('GET', { keys: [K.SAVED_BINS] }).then(function(result) {
      result = result || {};
      var bins = result[K.SAVED_BINS] || [];
      callback(Array.isArray(bins) ? bins : []);
    });
  };

  UsagiStorage.saveBINs = function(bins) {
    var data = {};
    data[K.SAVED_BINS] = bins;
    storageRequest('SET', data);
  };

  UsagiStorage.loadToggleState = function(toggleType, callback) {
    var keyMap = {
      'hitSound': K.TOGGLE_HIT_SOUND,
      'autoSS': K.TOGGLE_AUTO_SS
    };
    var key = keyMap[toggleType] || ('usagi_toggle_' + toggleType);
    storageRequest('GET', { keys: [key] }).then(function(result) {
      result = result || {};
      callback(result[key] !== undefined ? result[key] : true);
    });
  };

  UsagiStorage.saveToggleState = function(toggleType, value) {
    var keyMap = {
      'hitSound': K.TOGGLE_HIT_SOUND,
      'autoSS': K.TOGGLE_AUTO_SS
    };
    var key = keyMap[toggleType] || ('usagi_toggle_' + toggleType);
    var data = {};
    data[key] = value;
    storageRequest('SET', data);
  };

  UsagiStorage.loadSavedId = function(callback) {
    storageRequest('GET', { keys: [K.SAVED_ID] }).then(function(result) {
      result = result || {};
      callback(result[K.SAVED_ID] || '');
    });
  };

  UsagiStorage.saveId = function(id) {
    var data = {};
    data[K.SAVED_ID] = id;
    storageRequest('SET', data);
  };

  UsagiStorage.loadAllData = function(callback) {
    var allKeys = [];
    var kNames = Object.keys(K);
    for (var i = 0; i < kNames.length; i++) {
      allKeys.push(K[kNames[i]]);
    }
    storageRequest('GET', { keys: allKeys }).then(function(result) {
      result = result || {};
      callback(result);
    });
  };

})();
